#!/bin/bash
for filename in *.wav; do
    xxd -i $filename ${filename%%.*}.c
    UP=${filename%%.*}
    perl -pi -e 's/unsigned char /#include <avr\/pgmspace.h>\n\nconst PROGMEM uint8_t  /g' $UP.c
    printf '#ifndef '${UP^^}'_H\n#define '${UP^^}'_H\n\nextern const PROGMEM uint8_t '$UP'_wav[];\n\nextern unsigned int '$UP'_wav_len;\n\n#endif'  > ${filename%%.*}.h
    mkdir ../lib/$UP
    mv $UP.c ../lib/$UP
    mv $UP.h ../lib/$UP
done

