#ifndef BLA_H
#define BLA_H

extern const PROGMEM uint8_t bla_wav[];

extern unsigned int bla_wav_len;

#endif