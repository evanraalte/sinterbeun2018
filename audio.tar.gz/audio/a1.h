#ifndef A1_H
#define A1_H

extern const PROGMEM uint8_t a1_wav[];

extern unsigned int a1_wav_len;

#endif